const express = require('express');
const router = express.Router();
const helloController = require('../controllers/hello.controller');

router.get('/', helloController.HelloWorld);

router.get('/hi', helloController.HelloHi);

router.get('/hi/:name', helloController.HelloHiName);

router.post('/person', helloController.personAsJSON);

router.get('/img', helloController.getPersonImg);

router.get('/imgfilename', helloController.getPersonImgFromFileName);

module.exports = router;