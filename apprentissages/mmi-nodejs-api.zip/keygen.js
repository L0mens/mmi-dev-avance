let c = require('crypto').randomBytes(64).toString('hex');
console.log(c);