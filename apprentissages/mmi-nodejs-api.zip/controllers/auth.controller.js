const UserService = require('../services/user.service');
const jwt = require('jsonwebtoken');

exports.login = async (req,res)=>{
    let service = new UserService()
    let message = {
        "error" : "Invalid email/password"
    };
    let statusCode = 400;
    
    let userModel = await service.getUserByEmail(req.body.email);
    if(userModel){
        if(await service.verifyUserPassword(req.body.password, userModel))
        {
            statusCode = 200;
            message = {
                userId: userModel._id,
                token: jwt.sign(
                    { userId : userModel._id },
                    process.env.TOKEN_SECRET,
                    { expiresIn : '24h'}
                )
            }
        }

    }
    
    res.status(statusCode).send(message);

}

exports.register = async (req,res) =>{
    let service = new UserService()
    try {
        let user= await service.createUser(req.body);
        res.status(201).send({message : "L'utilisateur a bien été créé"});
    } catch (error) {
        res.status(400).send(error);
    }
}

exports.checkUser = async (req,res) =>{
    res.status(204).send()
}