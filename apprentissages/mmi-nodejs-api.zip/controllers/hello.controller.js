const Person = require('../models/Person')
// import PersonService from '../services/person.service';
const PersonService = require('../services/person.service')

var path = require('path');

exports.HelloWorld = (req, res) => {
    res.status(200).json({ message: "Hello World" });
}

exports.HelloHi = (req, res) => {
    let name = req.query.name ?? "No name"
    res.status(200).json({ message: `Hello ${name} ! ` });
}

exports.HelloHiName = (req, res) => {
    let name = req.params.name ?? "No name"
    res.status(200).json({ message: `Hello ${name} ! ` });
}

exports.personAsJSON = (req, res) => {
    let name = req.body.name ?? "No name"
    let age = req.body.age ?? 0
    let person = new Person(name,age)
    res.status(200).json(person);
}

exports.getPersonImg = (req, res) => {
    let filename = 'this-person-doesnt-exist.jpg'
    let p = path.resolve(`${process.env.IMGPATH}/${filename}`);
    res.sendFile(p)
}

exports.getPersonImgFromFileName = (req, res) => {
    let ps = new PersonService(process.env.IMGPATH);
    res.sendFile(ps.resolveFromFileName(req.query.filename))
}