const express = require('express')
const mongoose = require('mongoose');
const helloRouter = require('./routes/hello');
const userRouter = require('./routes/user');
const authRouter = require('./routes/auth');
const wss = require('./websocketserver');
const app = express()
const port = 3000

// Parse URL-encoded bodies (Envoyé par les HTML forms)
// Body x-www-url-encoded
app.use(express.urlencoded({ extended: true }));
// Parse JSON bodies (Envoyé par les clients API)
// Body Raw format JSON
app.use(express.json());
// Cela popule le req.body avec les infos envoyé

mongoose.connect('mongodb://127.0.0.1:27017/td')
  .then(() => console.log('Connexion à MongoDB réussie !'))
  .catch((err) => console.log(err));

app.use('/hello', helloRouter);  
app.use('/users', userRouter);  
app.use('/auth', authRouter);  


app.get('/', (req, res) => {
  res.send('Hello World!')
})



app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})